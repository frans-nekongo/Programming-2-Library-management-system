create
    definer = root@localhost procedure deleteC(IN idC int)
BEGIN
delete from customer
where idcustomer= idC;
END;

