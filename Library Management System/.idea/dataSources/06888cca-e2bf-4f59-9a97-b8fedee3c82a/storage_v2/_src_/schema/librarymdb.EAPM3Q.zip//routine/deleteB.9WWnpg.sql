create
    definer = root@localhost procedure deleteB(IN idB int)
BEGIN
delete from book
where idBook= idB;
END;

