create
    definer = root@localhost procedure selectB_name(IN bName varchar(20))
BEGIN
SELECT * FROM book
WHERE BookName = bName;
END;

