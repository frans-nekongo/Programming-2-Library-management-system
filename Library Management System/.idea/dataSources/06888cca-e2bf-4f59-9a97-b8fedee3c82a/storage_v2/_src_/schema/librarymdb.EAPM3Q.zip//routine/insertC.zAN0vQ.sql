create
    definer = root@localhost procedure insertC(IN idcustomer int, IN firstName varchar(20), IN lastname varchar(20),
                                               IN cellphonenumber varchar(20), IN username varchar(20),
                                               IN password_c varchar(20))
BEGIN
insert into customer(idcustomer,firstName,lastName,cellphoneNumber,username,password_c)
values(idcustomer,firstName,lastname,cellphonenumber,username,password_c);
END;

