create
    definer = root@localhost procedure selectC_usrname_pass(IN userN varchar(20), IN password_c varchar(20))
BEGIN
SELECT * FROM customer
WHERE username = userN and
password_c = password_c;
END;

