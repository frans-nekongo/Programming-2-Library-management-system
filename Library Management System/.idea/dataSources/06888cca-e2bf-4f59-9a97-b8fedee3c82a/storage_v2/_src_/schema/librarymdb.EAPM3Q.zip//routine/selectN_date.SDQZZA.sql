create
    definer = root@localhost procedure selectN_date(IN nDate date)
BEGIN
SELECT * FROM newspaper
WHERE Date = nDate; 
END;

