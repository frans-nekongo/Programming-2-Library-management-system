create
    definer = root@localhost procedure updateB_bc(IN Bid int, IN Bcount int)
BEGIN
UPDATE book
SET CountOfBooks = Bcount
WHERE idBook = Bid;
END;

