create
    definer = root@localhost procedure updateB_borw(IN Bid int)
BEGIN
UPDATE book
set CountOfBooks = CountOfBooks - 1 
where idBook = Bid and
CountOfBooks > 0 ;
END;

