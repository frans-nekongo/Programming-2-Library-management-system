create
    definer = root@localhost procedure updateC_cellN(IN idC int, IN cellN varchar(20))
BEGIN
UPDATE customer
SET cellphoneNumber = cellN
WHERE idcustomer = idC;
END;

