create
    definer = root@localhost procedure insertE(IN idE int, IN fName varchar(20), IN lName varchar(20),
                                               IN cellN varchar(20), IN posE varchar(20))
BEGIN
insert into employee(idEmployee,firstName,lastName,cellphoneN,positionE)
values(idE,fname,lname,cellN,posE);
END;

