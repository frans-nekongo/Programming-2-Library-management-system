create
    definer = root@localhost procedure deleteE(IN idE int)
BEGIN
delete from employee
where idEmployee= idE;
END;

