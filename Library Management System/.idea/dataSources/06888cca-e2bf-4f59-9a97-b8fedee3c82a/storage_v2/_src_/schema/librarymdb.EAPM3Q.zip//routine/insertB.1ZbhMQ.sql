create
    definer = root@localhost procedure insertB(IN idB int, IN BName varchar(20), IN BType varchar(20), IN idCount int,
                                               IN BCount int)
BEGIN
insert into book(idBook,BookName,BookType,countID,CountOfBooks)
values(idB,BName,BType,idCount,BCount);
END;

