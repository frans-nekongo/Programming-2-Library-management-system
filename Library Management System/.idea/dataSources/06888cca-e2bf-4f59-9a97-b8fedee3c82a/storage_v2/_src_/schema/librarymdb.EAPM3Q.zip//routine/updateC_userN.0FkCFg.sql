create
    definer = root@localhost procedure updateC_userN(IN idC int, IN usernameC varchar(20))
BEGIN
UPDATE customer
SET username = usernameC
WHERE idcustomer = idC;
END;

