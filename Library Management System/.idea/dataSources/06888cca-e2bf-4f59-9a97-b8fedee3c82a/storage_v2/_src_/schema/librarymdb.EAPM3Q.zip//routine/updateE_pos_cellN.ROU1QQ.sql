create
    definer = root@localhost procedure updateE_pos_cellN(IN idE int, IN posE varchar(20), IN cellN varchar(20))
BEGIN
UPDATE employee
SET positionE = posE,cellphoneN = cellN
WHERE idEmployee = idE;
END;

