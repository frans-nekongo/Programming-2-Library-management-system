create
    definer = root@localhost procedure selectB()
BEGIN
select* from book order by idBook;
END;

