create
    definer = root@localhost procedure selectC()
BEGIN
select* from customer order by idcustomer;
END;

