create
    definer = root@localhost procedure updateC_pass(IN idC int, IN pass_C varchar(20))
BEGIN
UPDATE customer
SET password_c = pass_C
WHERE idcustomer = idC;
END;

