create
    definer = root@localhost procedure selectE()
BEGIN
select* from Employee order by idEmployee;
end;

