create
    definer = root@localhost procedure selectN_publisher(IN nPublisher varchar(20))
BEGIN
SELECT * FROM newspaper
WHERE publisher = nPublisher; 
END;

